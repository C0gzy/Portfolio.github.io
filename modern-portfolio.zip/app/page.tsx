"use client"

import Portfolio from "../page"

export default function SyntheticV0PageForDeployment() {
  return <Portfolio />
}